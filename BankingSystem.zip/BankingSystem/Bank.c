/*Program to perform all Basics operation like 
- Create New Account
- Deposit Money in Account By Account Number
- Withdrawal Money in Account By Account Number
- View Details of single Account Holder by Account Number
- View Summery of all Customer 
- Transfer money from one customer to another customer 
   by Account Number
*/

/*Library file*/
#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<string.h>
#include<time.h>

//structure of account details

struct Account
{
	int accId;
	char custName[100];
	char contact[12];
	char pincode[15];
	int amount;
	char accType[20];
};

int accTypeNumber;
int cnt = 0;
struct Account acc[100];

// structure of withDraw amount details

struct WithDraw
{
   int accDetail;
   int totalAmt;
};
struct WithDraw W[100];
int flag = 0;
int cnt_1 = 0;

//structure of deposit amount details 

struct Deposit
{
	int accdetailD;
	int totalAmnt;
};

//structure of transaction money details

struct Transaction
{
	int accountIdSender;
	int accountIdReceiver;
	int amountMoney;
};

struct Transaction T[100];


struct Deposit D[100];
int cnt_2 = 0;
int flag1 = 0;
int cnt_3 = 0;

void transaction()
{
	int money,flag_2 = 0,flag_3=0,flag_4 = 0;
	printf("\n");
	printf("\n\t\t\t_________________________________________");
	printf("\n\t\t\t\t TRANSACTION PORTAL ");
	printf("\n\t\t\t_________________________________________");
	int senderId,receiverId;
	printf("\n\n\t\t\t\t Enter the Sender Account Number : ");
	scanf("%d",&senderId);
	for(int i=0;i<cnt;i++)
	{
		if( senderId == acc[i].accId )
		{
		 flag_2 = 1;
	     printf("\n\t\t\t\t Enter the Receiver Account Number : ");
         scanf("%d",&receiverId);
         for(int j = 0;j < cnt;j++)
         {
         if(senderId != receiverId && receiverId == acc[j].accId)
         {
         	flag_3 = 1;
            printf("\n\t\t\t\t Enter Amount : ");
            scanf("%d",&money);
            if(money < acc[i].amount)
            {
            	T[cnt_2].accountIdSender = senderId;
            	T[cnt_2].accountIdReceiver = receiverId;
            	T[cnt_2].amountMoney = money;
            	acc[i].amount = acc[i].amount - money;
            	acc[j].amount = acc[j].amount + money;
            }
            else
            {
            	flag_4 = 1;
            	break;
            }
         }
        }
        }
    }
    
    if(flag_2 == 0)
    	printf("\n\t\t\t\t Sender Account Number is Not Matched !!!");
    else if(flag_3 == 0)
    	printf("\n\t\t\t\t Receiver Account Number is Not Matched !!!");
    else if(flag_4 == 1)
        printf("\n\t\t\t\tSender Total Amount is less than Enter Amount !!!");
    else
    printf("\n\t\t\t\t Money Transfer Successfully ..."); 	
cnt_2++;
}

//function to print the transaction details

void transactionDetail(int acId)
{
	for(int i_1 =0;i_1 < cnt_2;i_1++)
	{
		if(acId == T[i_1].accountIdSender)
		{
			printf("\n\t\t\t_________________________________________");
			printf("\n\t\t\t\t Transfer Money : %d",T[i_1].amountMoney);
		}
		if(acId == T[i_1].accountIdReceiver)
		{
			printf("\n\t\t\t_________________________________________");
			printf("\n\t\t\t\t Received Money : %d",T[i_1].amountMoney);
		}
	}
}



// function to deposit money 

void deposit()
{
	flag1 = 0;
  printf("\n\t\t\t_________________________________________");
  printf("\n\t\t\t\t !! DEPOSIT PORTAL !! ");
  printf("\n\t\t\t_________________________________________");
  printf("\n\n\t\t\t\tEnter your Account Number : ");
  int ac;
  scanf("%d",&ac);
  for(int i=0;i<cnt;i++)
  {
   if(ac == acc[i].accId)
   {
   	D[cnt_2].accdetailD = acc[i].accId;
    printf("\n\t\t\t\t Deposit Amount : ");
    int amt;
    scanf("%d",&amt);
    flag1 = 1;
   	printf("\n\t\t\t\t Amount Deposit Successful ...");
   	D[cnt_2].totalAmnt = amt;
   	acc[i].amount = (acc[i].amount)+amt;
  }
  }
  cnt_2++;
  if(flag1 == 0)
  printf("\n\t\t\t\t NO RECORD EXISTS !!! ");
}

// function to print the deposit money Report 

void depositReport(int Id,int total)
{
	for(int i_1=0;i_1 < cnt_2;i_1++)
     {

     	if(Id == D[i_1].accdetailD)
     	{
     	 printf("\n\t\t\t_________________________________________");
         printf("\n\t\t\t\t DEPOSIT AMOUNT = %d",D[i_1].totalAmnt);
     	}
     }

}

//function for with draw money

void withDraw()
{
	flag = 0;
  printf("\n\t\t\t_________________________________________");
  printf("\n\t\t\t\t !!! WITHDRAW PORTAL !!! ");
  printf("\n\t\t\t_________________________________________");
  printf("\n\n\t\t\t\tEnter your Account Number : ");
  int ac;
  scanf("%d",&ac);
  for(int i=0;i<cnt;i++)
  {
   if(ac == acc[i].accId)
   {
   	flag = 1;
   	W[cnt_1].accDetail = acc[i].accId;
    printf("\n\t\t\t\t Withdrawal Amount : ");
    int amt;
   scanf("%d",&amt);
   if(amt <= acc[i].amount)
   {
   	printf("\n\t\t\t\t Amount Withdrawal Successful ...");
   	W[cnt_1].totalAmt = amt;
   	acc[i].amount = (acc[i].amount)-amt;
   }
   else 
   {
   	printf("\n\t\t\t\t Enter Amount is greater than your Total Amount ");
   }
  }
  }
  if(flag == 0)
  	printf("\n\t\t\t\t NO RECORD FOUND !!! ");
  cnt_1++;
}

//function to print out the withdrawal Report 

void withDrawalReport(int Id,int total)
{
  for(int i_1=0;i_1 < cnt_1;i_1++)
     {

     	if(Id == W[i_1].accDetail)
     	{
     	 printf("\n\t\t\t_________________________________________");
         printf("\n\t\t\t\t WITHDRAWAL AMOUNT = %d",W[i_1].totalAmt);
     	}
     }
}

//function to print the summary Report 

void summaryReport()
{
	printf("\n\t\t\t_________________________________________");
	printf("\n\t\t\t\t SUMMARY REPORT ");
	printf("\n\t\t\t_________________________________________");
	printf("\n");
	if(cnt > 0)
	{
	for(int i=0;i<cnt;i++)
	{
	 printf("\n\t\t\t_________________________________________");
	 printf("\n\t\t\t\t  !! %s !!",acc[i].custName);
	 printf("\n\t\t\t_________________________________________");	
     printf("\n\t\t\t\tAccount Number : %d",acc[i].accId);
     printf("\n\t\t\t\tContact Number : %s",acc[i].contact);
     printf("\n\t\t\t\tPinCode Number :%s",acc[i].pincode);
     printf("\n\t\t\t\tTotal Amount : %d",acc[i].amount);
     printf("\n\t\t\t\tAccount Type : %s",acc[i].accType);
    }
	}
	else
		printf("\n\t\t\t\t NO RECORD EXISTS !! ");
}

//function to print the Induvisual Report 

void viewReport()
{
	printf("\n\t\t\t_________________________________________");
	printf("\n\t\t\t\tCUSTOMER REPORT ");
	printf("\n\t\t\t_________________________________________");
	printf("\n");
	printf("\n\t\t\tEnter Your Account Number : ");
	int accountId;
	scanf("%d",&accountId);
	int flag = 1;
	for(int i=0;i<cnt;i++)
	{
	if(accountId == acc[i].accId)
	 {
	 	flag = 0;
	  printf("\n\t\t\t_________________________________________");
	  printf("\n\t\t\t\t REPORT [%d]",i+1);
	  printf("\n\t\t\t_________________________________________");	
      printf("\n\t\t\t\t Account Number : %d",acc[i].accId);
      printf("\n\t\t\t\t Customer Name : %s",acc[i].custName);
      printf("\n\t\t\t\t Contact Number : %s",acc[i].contact);
      printf("\n\t\t\t\t PinCode Number :%s",acc[i].pincode);
      printf("\n\t\t\t\t Total Amount : %d",acc[i].amount);
      printf("\n\t\t\t\t Account Type : %s",acc[i].accType);
      withDrawalReport(acc[i].accId,acc[i].amount);
      depositReport(acc[i].accId,acc[i].amount);
      transactionDetail(acc[i].accId);
     }
    }
    if(flag)
      printf("\n\t\t\t\t Account number %d is not exists ",accountId);
}

//function to create New Account 

void newAccount()
{
	
	printf("\n\t\t\t_________________________________________");
	printf("\n\t\t\t !!! INPUT CONTACT INFORMATION !!! ");
	printf("\n\t\t\t_________________________________________\n");
	printf("\n\t\t\t\t Customer Name : ");
	scanf("%s",acc[cnt].custName);
	printf("\n\t\t\t\t Contact : ");
	scanf("%s",acc[cnt].contact);
	printf("\n\t\t\t\t PinCode : ");
	scanf("%s",acc[cnt].pincode);
	printf("\n\t\t\t\t Initial Amount : ");
	scanf("%d",&acc[cnt].amount);
    printf("\n\t\t\t_________________________________________");
    printf("\n\t\t\t\t CHOOSE ACCOUNT TYPE ");
    printf("\n\t\t\t_________________________________________");
    printf("\n\t\t\t\t 1. SAVING \t 2. CURRENT");
    printf("\n\t\t\t\t 3. FIXED  \t 4. SALARY");
    printf("\n\t\t\t_________________________________________\n");
    printf("\n\t\t\t\t Choose Account Type Number : ");
    scanf("%s",acc[cnt].accType);

	 srand(time(0));
	 acc[cnt].accId = rand();
	printf("\n\t\t\t\t Hii %s your Account is created Successfully ...",acc[cnt].custName);
    printf("\n\t\t\t\t Your ACCOUNT NUMBER = %d ",acc[cnt].accId);	
	cnt++;	
}


int main()
{
	FILE *f,*f1;
	int password;
	f = fopen("authentication.txt","r+");
	while(1)
	{
		char ch = fgetc(f);
		if(ch == EOF)
			break;
		if(ch == '.')
		{
		  scanf("%d",&password);
		  if(password == 1024)
		  {
			
		    printf("\n\t\t\t\tCongrates,You have login Successfully ...");
            f1 = fopen("instruction.txt","r");
            while(1)
            {
            	char c1 = fgetc(f1);
            	if(c1 == EOF)
            	break;
            	printf("%c",c1); 
            }
            fclose(f1);
    	   }
		  else 
		  	printf("\n\t\t\t\t Sorry,Contact Admistrator...");
        }
        if(ch == '.')
        	continue;
		printf("%c",ch);
	}
     char choice[10];
     while(1)
     {
     printf("\n\n\t\t\t Enter your choice : ");
     scanf("%s",choice);

     switch(choice[0])
     {
     	case 'N':newAccount();
     	break;

     	case 'V':viewReport();
     	break;

     	case 'S':summaryReport();
     	break;

     	case 'W':withDraw();
     	break;

     	case 'D':deposit();
     	break;

     	case 'T':transaction();
     	break;

     	case 'E':exit(1);
     	default:printf("\n\t\t\t\tWrong choice ");
     }
    }
	fclose(f);
	return 0;
}
